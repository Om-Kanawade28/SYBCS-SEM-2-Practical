#include <stdio.h>
#include <stdlib.h>

struct tree {
    int key;
    struct tree *left, *right;
};

struct tree *create(int key) {
    struct tree *newNode = (struct tree *)malloc(sizeof(struct tree));
    newNode->key = key;
    newNode->left = newNode->right = NULL;
    return newNode;
}

struct tree *insert(struct tree *root, int key) {
    if (root == NULL)
        return create(key);

    if (key < root->key)
        root->left = insert(root->left, key);
    else
        root->right = insert(root->right, key);

    return root;
}

void inorder(struct tree *root) {
    if (root != NULL) {
        inorder(root->left);
        printf("%d ", root->key);
        inorder(root->right);
    }
}

struct tree *treecopy(struct tree *root) {
    if (root == NULL)
        return NULL;

    struct tree *temp = create(root->key);
    temp->left = treecopy(root->left);
    temp->right = treecopy(root->right);
    return temp;
}

int main() {
    struct tree *root = NULL;

    root = insert(root, 8);
    root = insert(root, 3);
    root = insert(root, 10);
    root = insert(root, 1);
    root = insert(root, 6);
    root = insert(root, 4);
    root = insert(root, 7);
    root = insert(root, 14);
    root = insert(root, 13);

    printf("Inorder traversal of the original tree:\n");
    inorder(root);
    printf("\n");

    struct tree *root1 = treecopy(root);

    printf("Inorder traversal of the copied tree:\n");
    inorder(root1);
    printf("\n");

    return 0;
}
