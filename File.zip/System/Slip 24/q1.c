#include <stdio.h>
#include <stdlib.h>

struct tree {
    int data;
    struct tree *left, *right;
};

struct tree* createNode(int data) {
    struct tree* newNode = (struct tree*)malloc(sizeof(struct tree));
    newNode->data = data;
    newNode->left = newNode->right = NULL;
    return newNode;
}

struct tree* insert(struct tree* root, int data) {
    if (root == NULL) {
        return createNode(data);
    }
    if (data < root->data) {
        root->left = insert(root->left, data);
    } else if (data > root->data) {
        root->right = insert(root->right, data);
    }
    return root;
}

int countLeafNodes(struct tree *root) {
    if (root == NULL) {
        return 0;
    }
    if (root->left == NULL && root->right == NULL) {
        return 1;  
    }
    return countLeafNodes(root->left) + countLeafNodes(root->right);
}

int main() {
    struct tree *root = NULL;

    root = insert(root, 50);
    insert(root, 30);
    insert(root, 40);
    insert(root, 60);
    insert(root, 70);
    insert(root, 90);

    printf("Leaf nodes: %d\n", countLeafNodes(root));
}