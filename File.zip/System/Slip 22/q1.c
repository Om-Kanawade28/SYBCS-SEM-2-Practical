#include <stdio.h>
#include <stdlib.h>

int *bst;
int size = 0;

void create() {
    int n, value;
    printf("Enter how many elements to enter: ");
    scanf("%d", &n);
    bst = realloc(bst, (size + n) * sizeof(int));
    for (int i = 0; i < n; i++) {
        printf("Enter value: ");
        scanf("%d", &value);
        bst[size++] = value;
    }
}

int search(int value) {
    for (int i = 0; i < size; i++)
        if (bst[i] == value) return 1;
    return 0;
}

void inorder(int index) {
    if (index >= size) return;
    inorder(2 * index + 1);
    printf("%d ", bst[index]);
    inorder(2 * index + 2);
}

int main() {
    int choice, value;
    bst = malloc(0);
    while (1) {
        printf("\n1. Create\n2. Search\n3. Inorder Traversal\nChoice: ");
        scanf("%d", &choice);
        switch (choice) {
            case 1:
                create();
                break;
            case 2:
                printf("Enter value to search: ");
                scanf("%d", &value);
                printf(search(value) ? "Found\n" : "Not Found\n");
                break;
            case 3:
                inorder(0);
                printf("\n");
                break;
            default:
                return 0;
        }
    }
} 
