<?php
function reverseString($str) {
    return strrev($str);
}
$result = "";
if ($_SERVER["REQUEST_METHOD"] ?? '' == "POST") {
    $inputString = $_POST['inputString'] ?? '';
    $operation = $_POST['operation'] ?? '';
    if ($operation == "reverse") 
        $result = "Reversed String: " . reverseString($inputString);
}
?>
<form method="post">
    <label>Enter a String:</label>
    <input type="text" name="inputString" required>
    <br>
    <input type="radio" name="operation" value="reverse" required> Reverse String
    <br>
    <button type="submit">Submit</button>
</form>
<?php
if ($result) echo $result;
?>
