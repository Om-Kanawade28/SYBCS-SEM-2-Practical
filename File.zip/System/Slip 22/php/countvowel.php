<?php
function countVowels($str) {
    return preg_match_all('/[aeiouAEIOU]/', $str);
}

$result = ""; 

if ($_SERVER["REQUEST_METHOD"] ?? '' == "POST") {
    $inputString = $_POST['inputString'] ?? '';
    $result = "Total Vowels: " . countVowels($inputString);
}
?>

<form method="post">
    <label>Enter a String:</label>
    <input type="text" name="inputString" required>
    <button type="submit">Count Vowels</button>
</form>

<?php
if ($result) echo $result;
?>