<?php
function trimWhitespace($str) {
    return ltrim($str);
}

$result = "";

if ($_SERVER["REQUEST_METHOD"] ?? '' == "POST") {
    $inputString = $_POST['inputString'] ?? '';
    $result = "Trimmed String: '" . trimWhitespace($inputString) . "'";
}
?>

<form method="post">
    <label>Enter a String:</label>
    <input type="text" name="inputString" required>
    <button type="submit">Trim Whitespaces</button>
</form>

<?php
if ($result) echo $result;
?>