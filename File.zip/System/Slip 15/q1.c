#include <stdio.h>
#include <stdlib.h>
typedef struct Node {
    int vertex;
    struct Node* next;
} Node;
typedef struct Graph {
    int vertices;
    Node** adjList;
    int* visited;
} Graph;
Node* createNode(int v) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->vertex = v;
    newNode->next = NULL;
    return newNode;
}
Graph* createGraph(int vertices) {
    Graph* graph = (Graph*)malloc(sizeof(Graph));
    graph->vertices = vertices;
    graph->adjList = (Node**)malloc(vertices * sizeof(Node*));
    graph->visited = (int*)malloc(vertices * sizeof(int));
    for (int i = 0; i < vertices; i++) {
        graph->adjList[i] = NULL;
        graph->visited[i] = 0;
    }
    return graph;
}
void addEdge(Graph* graph, int src, int dest) {
    Node* newNode = createNode(dest);
    newNode->next = graph->adjList[src - 1];
    graph->adjList[src - 1] = newNode;
    newNode = createNode(src);
    newNode->next = graph->adjList[dest - 1];
    graph->adjList[dest - 1] = newNode;
}
void DFS(Graph* graph, int vertex) {
    printf("%d ", vertex);
    graph->visited[vertex - 1] = 1;
    Node* temp = graph->adjList[vertex - 1];
    while (temp) {
        int adjVertex = temp->vertex;
        if (!graph->visited[adjVertex - 1])
            DFS(graph, adjVertex);
        temp = temp->next;
    }
}
void printGraph(Graph* graph) {
    printf("Adjacency List:\n");
    for (int i = 0; i < graph->vertices; i++) {
        printf("Vertex %d: ", i + 1);
        Node* temp = graph->adjList[i];
        while (temp) {
            printf("%d -> ", temp->vertex);
            temp = temp->next;
        }
        printf("NULL\n");
    }
}
int main() {
    int vertices, edges, src, dest, start;
    printf("Enter number of vertices: ");
    scanf("%d", &vertices);
    Graph* graph = createGraph(vertices);
    printf("Enter number of edges: ");
    scanf("%d", &edges);
    printf("Enter the edges (start_vertex end_vertex):\n");
    for (int i = 0; i < edges; i++) {
        scanf("%d %d", &src, &dest);
        addEdge(graph, src, dest);
    }
    printGraph(graph);
    printf("Enter the starting vertex for DFS: ");
    scanf("%d", &start);
    printf("DFS Traversal:\n");
    DFS(graph, start);
    return 0;
}
