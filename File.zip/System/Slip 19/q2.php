<?php
$file = "item.dat";
if ($fp = fopen($file, 'r')) {
    echo "<table border=1><tr><th>Item Code<th>Item Name<th>Unit Sold<th>Rate<th>Total";
    $gt = 0;
    while ($line = fgets($fp)) {
        $item = explode(',', $line);
        $units = (float) trim($item[2]);
        $rate = (float) trim($item[3]);
        $total = $units * $rate;
        $gt += $total;
        echo "<tr><td>" . htmlspecialchars(trim($item[0])) . "<td>" . htmlspecialchars(trim($item[1])) . "<td>" . $units . "<td>" . $rate . "<td>" . $total;
    }
    echo "<tr><td colspan=4>Total<td>" . $gt;
    echo "</table>";
    fclose($fp);
} else {
    echo "Error: $file";
}
?>