<?php
$servername = "localhost";
$username = "root";
$password = "";

$conn = new mysqli($servername, $username, $password);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$sql = "CREATE DATABASE IF NOT EXISTS real_estate";
if ($conn->query($sql) !== TRUE) die("Error creating database: " . $conn->error);

$conn = new mysqli($servername, $username, $password, "real_estate");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$sql = "CREATE TABLE IF NOT EXISTS Owner (
    oname VARCHAR(100) PRIMARY KEY,
    address TEXT,
    phone VARCHAR(20)
)";
if ($conn->query($sql) !== TRUE) die("Error creating Owner table: " . $conn->error);

$sql = "CREATE TABLE IF NOT EXISTS Property (
    pno INT PRIMARY KEY,
    description TEXT,
    area DECIMAL(10,2),
    oname VARCHAR(100),
    FOREIGN KEY (oname) REFERENCES Owner(oname) ON DELETE CASCADE
)";
if ($conn->query($sql) !== TRUE) die("Error creating Property table: " . $conn->error);

$conn->close();
?>
