#include <stdio.h>
#include <stdlib.h>

int *bst;
int size = 0;

void create() {
    int n, value;
    printf("Enter how many elements to enter: ");
    scanf("%d", &n);
    bst = realloc(bst, (size + n) * sizeof(int));
    for (int i = 0; i < n; i++) {
        printf("Enter value: ");
        scanf("%d", &value);
        bst[size++] = value;
    }
    printf("Elements in BST: ");
    for (int i = 0; i < size; i++) {
        printf("%d ", bst[i]);
    }
    printf("\n");
}

int search(int value) {
    for (int i = 0; i < size; i++)
        if (bst[i] == value) return 1;
    return 0;
}

void preorder(int index) {
    if (index >= size) return;
    printf("%d ", bst[index]);
    preorder(2 * index + 1);
    preorder(2 * index + 2);
}

int main() {
    int choice, value;
    bst = malloc(0);
    while (1) {
        printf("\n1. Create\n2. Search\n3. Preorder Traversal\nChoice: ");
        scanf("%d", &choice);
        switch (choice) {
            case 1:
                create();
                break;
            case 2:
                printf("Enter value to search: ");
                scanf("%d", &value);
                printf(search(value) ? "Found\n" : "Not Found\n");
                break;
            case 3:
                preorder(0);
                printf("\n");
                break;
            default:
                return 0;
        }
    }
}
