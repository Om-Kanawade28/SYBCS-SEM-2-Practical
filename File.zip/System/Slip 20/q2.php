<?php
    $filename = readline("Enter your desired file name you want to open => ");

    echo "Type : " . filetype($filename) . "\n";
    echo "Accessed : " . date("Y-m-d H:i:s" ,  fileatime($filename)) . "\n";
    echo "Filesize : " . filesize($filename) . "\n";
    unlink($filename);
    echo "File Deleted";
?>